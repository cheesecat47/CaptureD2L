# CaptureD2L

CaptureD2L is a web page for invert terminal image from dark mode to light.

## Installation

### Requirements

- Docker & Docker-compose

### Run

```bash
$ docker-compose up -d --build
```

Go to <http://localhost/>

## Usage

Go to

- About page: <http://localhost/about>
- Blog(Description in Korean): <https://velog.io/@cheesecat47/CaptureD2L-%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8-%EC%86%8C%EA%B0%9C>

## Maintainers

[@cheesecat47](https://github.com/cheesecat47): cheesecat47@gmail.com
