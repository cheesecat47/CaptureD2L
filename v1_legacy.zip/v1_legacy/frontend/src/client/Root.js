import React from "react";
import App from "../shared/App";

const Root = () => (
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

export default Root;
